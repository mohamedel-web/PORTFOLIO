"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import { useLanguage } from "@/lib/i18n/LanguageContext";

const sectionIds = [
  "about",
  "skills",
  "experience",
  "projects",
  "education",
  "github",
  "contact",
] as const;

export default function Navbar() {
  const { t, lang, toggleLang } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "py-3" : "py-6"
      }`}
    >
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6">
        <div
          className={`flex items-center gap-4 rounded-full px-4 py-2 transition-all duration-500 ${
            scrolled ? "glass" : "border border-transparent bg-transparent"
          }`}
        >
          <button
            onClick={() => scrollTo("top")}
            className="flex h-8 w-8 items-center justify-center rounded-full border border-white/10 bg-ink-800 font-mono text-[11px] tracking-widest text-mist-50"
            aria-label="Home"
          >
            MH
          </button>
          <nav className="hidden items-center gap-6 lg:flex">
            {sectionIds.map((id) => (
              <button
                key={id}
                onClick={() => scrollTo(id)}
                className="underline-grow font-mono text-[11px] uppercase tracking-[0.14em] text-mist-400 transition-colors hover:text-mist-50"
              >
                {t.nav[id]}
              </button>
            ))}
          </nav>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={toggleLang}
            className="glass flex items-center gap-1 rounded-full px-3 py-2 font-mono text-[11px] uppercase tracking-widest text-mist-200 transition-colors hover:text-white"
            aria-label="Toggle language"
          >
            <span className={lang === "en" ? "text-white" : "text-mist-600"}>EN</span>
            <span className="text-mist-600">/</span>
            <span className={lang === "fr" ? "text-white" : "text-mist-600"}>FR</span>
          </button>

          <button
            onClick={() => scrollTo("contact")}
            className="hidden rounded-full bg-signal-500 px-4 py-2 text-[11px] font-medium uppercase tracking-[0.14em] text-white transition-transform hover:scale-[1.03] hover:bg-signal-600 sm:block"
          >
            {t.nav.cta}
          </button>

          <button
            onClick={() => setOpen(true)}
            className="glass flex h-9 w-9 items-center justify-center rounded-full text-mist-200 lg:hidden"
            aria-label="Open menu"
          >
            <Menu className="h-4 w-4" />
          </button>
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex flex-col bg-ink-950/98 backdrop-blur-xl lg:hidden"
          >
            <div className="flex items-center justify-between px-6 py-6">
              <span className="font-mono text-xs tracking-widest text-mist-400">
                MENU
              </span>
              <button
                onClick={() => setOpen(false)}
                className="glass flex h-9 w-9 items-center justify-center rounded-full text-mist-200"
                aria-label="Close menu"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            <nav className="flex flex-1 flex-col items-start justify-center gap-6 px-8">
              {sectionIds.map((id, i) => (
                <motion.button
                  key={id}
                  initial={{ opacity: 0, x: -12 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.05 * i }}
                  onClick={() => scrollTo(id)}
                  className="text-3xl font-light tracking-tight text-mist-50"
                >
                  {t.nav[id]}
                </motion.button>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
