"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import { skillGroups } from "@/lib/data";
import RevealOnScroll from "@/components/ui/RevealOnScroll";

export default function Skills() {
  const { t } = useLanguage();

  return (
    <section id="skills" className="relative border-t border-white/5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.skills.eyebrow}
          </span>
        </RevealOnScroll>

        <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <RevealOnScroll delay={0.05}>
            <h2 className="max-w-lg text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
              {t.skills.title}
            </h2>
          </RevealOnScroll>
          <RevealOnScroll delay={0.1}>
            <p className="max-w-xs text-sm leading-relaxed text-mist-500">{t.skills.sub}</p>
          </RevealOnScroll>
        </div>

        <div className="mt-14 grid gap-4 md:grid-cols-2">
          {skillGroups.map((group, i) => (
            <RevealOnScroll key={group.key} delay={0.05 * i}>
              <div className="glass group h-full rounded-2xl p-7 transition-colors hover:border-signal-500/30">
                <div className="flex items-center justify-between">
                  <h3 className="font-mono text-xs uppercase tracking-[0.16em] text-mist-400">
                    {t.skills.categories[group.key as keyof typeof t.skills.categories]}
                  </h3>
                  <span className="font-mono text-[10px] text-mist-700">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  {group.items.map((item) => (
                    <span
                      key={item}
                      className="rounded-full border border-white/8 bg-white/[0.02] px-3 py-1.5 text-xs text-mist-200 transition-all hover:border-signal-500/50 hover:bg-signal-500/10 hover:text-white"
                    >
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
}
