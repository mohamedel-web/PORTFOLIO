"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import { contactInfo } from "@/lib/data";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import AnimatedCounter from "@/components/ui/AnimatedCounter";
import { Github, ArrowUpRight } from "lucide-react";

// deterministic pseudo-random contribution intensities (0-4)
function cellIntensity(i: number) {
  const v = Math.abs(Math.sin(i * 12.9898) * 43758.5453) % 1;
  if (v > 0.86) return 4;
  if (v > 0.68) return 3;
  if (v > 0.48) return 2;
  if (v > 0.28) return 1;
  return 0;
}

const intensityColor = [
  "bg-white/[0.04]",
  "bg-signal-500/25",
  "bg-signal-500/45",
  "bg-signal-500/70",
  "bg-signal-glow",
];

export default function GithubStats() {
  const { t } = useLanguage();
  const cells = Array.from({ length: 17 * 7 });

  return (
    <section id="github" className="relative border-t border-white/5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.github.eyebrow}
          </span>
        </RevealOnScroll>

        <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <RevealOnScroll delay={0.05}>
            <h2 className="max-w-lg text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
              {t.github.title}
            </h2>
          </RevealOnScroll>
          <RevealOnScroll delay={0.1}>
            <a
              href={contactInfo.github}
              target="_blank"
              rel="noreferrer"
              className="group flex items-center gap-1.5 text-sm text-mist-300 transition-colors hover:text-white"
            >
              <Github className="h-4 w-4" />
              {t.github.viewProfile}
              <ArrowUpRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </RevealOnScroll>
        </div>

        <RevealOnScroll delay={0.15} className="mt-12">
          <div className="glass overflow-x-auto rounded-2xl p-6 sm:p-8">
            <div
              className="grid w-max grid-flow-col gap-[3px]"
              style={{ gridTemplateRows: "repeat(7, 10px)" }}
            >
              {cells.map((_, i) => (
                <div
                  key={i}
                  className={`h-[10px] w-[10px] rounded-[2px] ${intensityColor[cellIntensity(i)]}`}
                />
              ))}
            </div>
            <p className="mt-4 text-xs text-mist-500">{t.github.sub}</p>
          </div>
        </RevealOnScroll>

        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
          {t.github.stats.map((stat, i) => (
            <RevealOnScroll key={stat.label} delay={0.05 * i}>
              <div className="glass rounded-2xl p-6 text-center">
                <AnimatedCounter
                  value={stat.value}
                  className="block font-mono text-2xl text-mist-50 sm:text-3xl"
                />
                <span className="mt-2 block text-[11px] leading-snug text-mist-500">
                  {stat.label}
                </span>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
}
