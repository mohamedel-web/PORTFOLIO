"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import { projects } from "@/lib/data";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import { Github, ArrowUpRight, Sparkles } from "lucide-react";

function ProjectVisual({ seed }: { seed: number }) {
  return (
    <div className="relative h-44 w-full overflow-hidden rounded-xl border border-white/5 bg-ink-900">
      <div className="grid-overlay absolute inset-0 opacity-60" />
      <div
        className="absolute h-40 w-40 rounded-full blur-3xl"
        style={{
          background: "radial-gradient(circle, rgba(59,130,246,0.35), transparent 70%)",
          top: `${(seed * 17) % 60}%`,
          left: `${(seed * 29) % 70}%`,
        }}
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="font-mono text-[10px] uppercase tracking-[0.3em] text-mist-600">
          preview
        </span>
      </div>
    </div>
  );
}

export default function Projects() {
  const { t, lang } = useLanguage();

  return (
    <section id="projects" className="relative border-t border-white/5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.projects.eyebrow}
          </span>
        </RevealOnScroll>

        <div className="mt-6 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <RevealOnScroll delay={0.05}>
            <h2 className="max-w-lg text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
              {t.projects.title}
            </h2>
          </RevealOnScroll>
          <RevealOnScroll delay={0.1}>
            <p className="max-w-xs text-sm leading-relaxed text-mist-500">{t.projects.sub}</p>
          </RevealOnScroll>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {projects.map((project, i) => (
            <RevealOnScroll
              key={project.id}
              delay={0.06 * i}
              className={project.featured ? "md:col-span-1" : "md:col-span-1"}
            >
              <div className="glass group flex h-full flex-col rounded-2xl p-6 transition-all hover:-translate-y-1 hover:border-signal-500/30 hover:shadow-glow">
                <ProjectVisual seed={i + 1} />
                <div className="mt-6 flex items-center gap-2">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-signal-glow">
                    {project.tag[lang]}
                  </span>
                </div>
                <h3 className="mt-2 text-xl text-mist-50">{project.title[lang]}</h3>
                <p className="mt-3 flex-1 text-sm leading-relaxed text-mist-400">
                  {project.description[lang]}
                </p>

                <div className="mt-5">
                  <span className="font-mono text-[10px] uppercase tracking-widest text-mist-600">
                    {t.projects.tech}
                  </span>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {project.tech.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full border border-white/8 px-2.5 py-1 text-[11px] text-mist-300"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="mt-6 flex items-center gap-3 border-t border-white/5 pt-5">
                  <a
                    href={project.github}
                    className="flex items-center gap-1.5 text-xs font-medium text-mist-200 transition-colors hover:text-white"
                  >
                    <Github className="h-3.5 w-3.5" />
                    {t.projects.github}
                  </a>
                  <span className="text-mist-700">·</span>
                  {project.demo ? (
                    <a
                      href={project.demo}
                      className="flex items-center gap-1.5 text-xs font-medium text-mist-200 transition-colors hover:text-white"
                    >
                      <ArrowUpRight className="h-3.5 w-3.5" />
                      {t.projects.demo}
                    </a>
                  ) : (
                    <span className="flex items-center gap-1.5 text-xs text-mist-600">
                      {t.projects.soon}
                    </span>
                  )}
                </div>
              </div>
            </RevealOnScroll>
          ))}

          <RevealOnScroll delay={0.06 * projects.length}>
            <div className="flex h-full min-h-[280px] flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/10 p-6 text-center">
              <Sparkles className="h-5 w-5 text-mist-600" />
              <p className="max-w-[220px] text-sm text-mist-500">{t.projects.more}</p>
            </div>
          </RevealOnScroll>
        </div>
      </div>
    </section>
  );
}
