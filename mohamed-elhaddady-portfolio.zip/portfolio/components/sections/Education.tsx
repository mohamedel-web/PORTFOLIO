"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import { education } from "@/lib/data";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import { GraduationCap } from "lucide-react";

export default function Education() {
  const { t, lang } = useLanguage();

  return (
    <section id="education" className="relative border-t border-white/5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.education.eyebrow}
          </span>
        </RevealOnScroll>

        <RevealOnScroll delay={0.05}>
          <h2 className="mt-6 max-w-lg text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
            {t.education.title}
          </h2>
        </RevealOnScroll>

        <div className="relative mt-16 pl-8">
          <div className="absolute left-[7px] top-2 h-[calc(100%-16px)] w-px bg-white/10" />
          <div className="flex flex-col gap-10">
            {education.map((item, i) => (
              <RevealOnScroll key={item.id} delay={0.06 * i}>
                <div className="relative">
                  <span
                    className={`absolute -left-8 top-1.5 flex h-4 w-4 items-center justify-center rounded-full border ${
                      item.current
                        ? "border-signal-500 bg-signal-500/20"
                        : "border-white/15 bg-ink-900"
                    }`}
                  >
                    {item.current && (
                      <span className="h-1.5 w-1.5 rounded-full bg-signal-glow" />
                    )}
                  </span>
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h3 className="flex items-center gap-2 text-lg text-mist-50">
                      <GraduationCap className="h-4 w-4 text-mist-500" />
                      {item.degree[lang]}
                    </h3>
                    <span className="font-mono text-xs uppercase tracking-widest text-mist-500">
                      {item.period}
                    </span>
                  </div>
                  <p className="mt-1.5 pl-6 text-sm text-mist-500">{item.school}</p>
                </div>
              </RevealOnScroll>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
