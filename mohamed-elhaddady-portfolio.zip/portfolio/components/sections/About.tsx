"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import AnimatedCounter from "@/components/ui/AnimatedCounter";

export default function About() {
  const { t } = useLanguage();

  return (
    <section id="about" className="relative py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.about.eyebrow}
          </span>
        </RevealOnScroll>

        <div className="mt-6 grid gap-16 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <RevealOnScroll delay={0.05}>
              <h2 className="max-w-lg text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
                {t.about.title}
              </h2>
            </RevealOnScroll>

            <RevealOnScroll delay={0.15} className="mt-8 space-y-5">
              <p className="text-base leading-relaxed text-mist-400">{t.about.p1}</p>
              <p className="text-base leading-relaxed text-mist-400">{t.about.p2}</p>
              <p className="text-base leading-relaxed text-mist-400">{t.about.p3}</p>
            </RevealOnScroll>

            <RevealOnScroll delay={0.25} className="mt-10">
              <blockquote className="border-l-2 border-signal-500/60 pl-6 text-lg font-light italic leading-relaxed text-mist-200">
                "{t.about.quote}"
              </blockquote>
            </RevealOnScroll>
          </div>

          <RevealOnScroll delay={0.2}>
            <div className="glass grid grid-cols-2 gap-px overflow-hidden rounded-2xl shadow-card">
              {t.about.stats.map((stat, i) => (
                <div
                  key={i}
                  className="flex flex-col justify-center gap-2 border-white/5 bg-ink-900/40 p-8"
                >
                  <AnimatedCounter
                    value={stat.value}
                    className="font-mono text-3xl font-medium text-mist-50 sm:text-4xl"
                  />
                  <span className="text-xs leading-snug text-mist-500">{stat.label}</span>
                </div>
              ))}
            </div>
          </RevealOnScroll>
        </div>
      </div>
    </section>
  );
}
