"use client";

import { useState } from "react";
import { useLanguage } from "@/lib/i18n/LanguageContext";
import { contactInfo } from "@/lib/data";
import RevealOnScroll from "@/components/ui/RevealOnScroll";
import { Mail, Phone, Linkedin, Github, Download, Send } from "lucide-react";

export default function Contact() {
  const { t } = useLanguage();
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio contact — ${form.name || "New message"}`);
    const body = encodeURIComponent(
      `${form.message}\n\n— ${form.name} (${form.email})`
    );
    window.location.href = `mailto:${contactInfo.email}?subject=${subject}&body=${body}`;
  };

  const links = [
    { icon: Mail, label: t.contact.email, value: contactInfo.email, href: `mailto:${contactInfo.email}` },
    { icon: Phone, label: t.contact.phone, value: contactInfo.phone, href: `tel:${contactInfo.phone.replace(/\s/g, "")}` },
    { icon: Linkedin, label: t.contact.linkedin, value: "in/mohamed-el-haddady", href: contactInfo.linkedin },
    { icon: Github, label: t.contact.github, value: "github.com/…", href: contactInfo.github },
  ];

  return (
    <section id="contact" className="relative border-t border-white/5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.contact.eyebrow}
          </span>
        </RevealOnScroll>

        <RevealOnScroll delay={0.05}>
          <h2 className="mt-6 max-w-xl text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
            {t.contact.title}
          </h2>
        </RevealOnScroll>
        <RevealOnScroll delay={0.1}>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-mist-500">{t.contact.sub}</p>
        </RevealOnScroll>

        <div className="mt-14 grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <RevealOnScroll delay={0.1}>
            <div className="flex h-full flex-col gap-3">
              {links.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                  target={link.href.startsWith("http") ? "_blank" : undefined}
                  rel="noreferrer"
                  className="glass group flex items-center gap-4 rounded-2xl p-5 transition-all hover:border-signal-500/30 hover:bg-white/[0.04]"
                >
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-white/10 text-mist-300 transition-colors group-hover:border-signal-500/50 group-hover:text-signal-glow">
                    <link.icon className="h-4 w-4" />
                  </span>
                  <span className="flex flex-col">
                    <span className="font-mono text-[10px] uppercase tracking-widest text-mist-600">
                      {link.label}
                    </span>
                    <span className="text-sm text-mist-100">{link.value}</span>
                  </span>
                </a>
              ))}
              <a
                href="/Mohamed-El-Haddady-CV.pdf"
                download
                className="mt-2 flex items-center justify-center gap-2 rounded-2xl bg-signal-500 px-5 py-4 text-sm font-medium text-white transition-transform hover:scale-[1.02] hover:bg-signal-600"
              >
                <Download className="h-4 w-4" />
                {t.contact.cv}
              </a>
            </div>
          </RevealOnScroll>

          <RevealOnScroll delay={0.15}>
            <form onSubmit={handleSubmit} className="glass flex h-full flex-col gap-5 rounded-2xl p-7">
              <div>
                <label className="font-mono text-[10px] uppercase tracking-widest text-mist-500">
                  {t.contact.formName}
                </label>
                <input
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder={t.contact.formPlaceholderName}
                  className="mt-2 w-full rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 text-sm text-mist-50 placeholder:text-mist-700 outline-none transition-colors focus:border-signal-500/60"
                />
              </div>
              <div>
                <label className="font-mono text-[10px] uppercase tracking-widest text-mist-500">
                  {t.contact.formEmail}
                </label>
                <input
                  required
                  type="email"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder={t.contact.formPlaceholderEmail}
                  className="mt-2 w-full rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 text-sm text-mist-50 placeholder:text-mist-700 outline-none transition-colors focus:border-signal-500/60"
                />
              </div>
              <div className="flex flex-1 flex-col">
                <label className="font-mono text-[10px] uppercase tracking-widest text-mist-500">
                  {t.contact.formMessage}
                </label>
                <textarea
                  required
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  placeholder={t.contact.formPlaceholderMessage}
                  rows={5}
                  className="mt-2 w-full flex-1 resize-none rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3 text-sm text-mist-50 placeholder:text-mist-700 outline-none transition-colors focus:border-signal-500/60"
                />
              </div>
              <button
                type="submit"
                className="group flex items-center justify-center gap-2 rounded-lg bg-signal-500 px-5 py-3.5 text-sm font-medium text-white transition-all hover:scale-[1.01] hover:bg-signal-600"
              >
                {t.contact.formSend}
                <Send className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </button>
            </form>
          </RevealOnScroll>
        </div>
      </div>
    </section>
  );
}
