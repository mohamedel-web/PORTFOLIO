"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowDown, Download, ArrowUpRight } from "lucide-react";
import { useLanguage } from "@/lib/i18n/LanguageContext";
import ConvergenceCurve from "@/components/visuals/ConvergenceCurve";

function useTypewriter(text: string, speed = 45) {
  const [display, setDisplay] = useState("");

  useEffect(() => {
    setDisplay("");
    let i = 0;
    const interval = setInterval(() => {
      i += 1;
      setDisplay(text.slice(0, i));
      if (i >= text.length) clearInterval(interval);
    }, speed);
    return () => clearInterval(interval);
  }, [text, speed]);

  return display;
}

function Avatar() {
  const [errored, setErrored] = useState(false);

  return (
    <div className="relative mx-auto h-40 w-40 sm:h-48 sm:w-48">
      <div className="absolute -inset-3 rounded-full bg-gradient-to-br from-signal-500/30 via-transparent to-transparent blur-2xl" />
      <div className="glass relative flex h-full w-full items-center justify-center overflow-hidden rounded-full border-white/10 shadow-glow">
        {!errored ? (
          <img
            src="/profile.jpg"
            alt="Mohamed El-Haddady"
            className="h-full w-full object-cover"
            onError={() => setErrored(true)}
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center bg-gradient-to-br from-ink-800 to-ink-900">
            <span className="font-mono text-3xl tracking-widest text-mist-200">
              MH
            </span>
            <span className="mt-1 font-mono text-[9px] uppercase tracking-[0.2em] text-mist-600">
              add /public/profile.jpg
            </span>
          </div>
        )}
      </div>
      <span className="glass absolute -bottom-2 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-full px-3 py-1 font-mono text-[10px] uppercase tracking-widest text-signal-glow">
        <span className="mr-1.5 inline-block h-1.5 w-1.5 rounded-full bg-emerald-400 align-middle" />
        Morocco
      </span>
    </div>
  );
}

export default function Hero() {
  const { t } = useLanguage();
  const role = useTypewriter(t.hero.role, 40);

  return (
    <section
      id="top"
      className="relative flex min-h-[100svh] flex-col justify-center overflow-hidden pt-28 pb-16"
    >
      <div className="grid-overlay absolute inset-0" aria-hidden="true" />

      {/* floating blobs */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-32 top-1/3 h-72 w-72 animate-blob rounded-full bg-signal-500/20 blur-[100px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -right-24 top-1/4 h-80 w-80 animate-blob rounded-full bg-indigo-500/10 blur-[110px]"
        style={{ animationDelay: "4s" }}
      />

      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-[340px] opacity-70">
        <ConvergenceCurve />
      </div>

      <div className="relative mx-auto flex w-full max-w-6xl flex-col items-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <Avatar />
        </motion.div>

        <motion.span
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="eyebrow mt-8 flex items-center gap-2 text-mist-400"
        >
          <span className="h-1.5 w-1.5 rounded-full bg-signal-500" />
          {t.hero.eyebrow}
        </motion.span>

        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.25 }}
          className="mt-4 h-5 font-mono text-xs uppercase tracking-[0.2em] text-signal-glow sm:text-sm"
        >
          {role}
          <span className="ml-0.5 inline-block h-3 w-[2px] animate-pulse bg-signal-glow align-middle" />
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.35, ease: [0.16, 1, 0.3, 1] }}
          className="mt-6 max-w-4xl text-balance text-4xl font-light leading-[1.05] tracking-tightest text-mist-50 sm:text-6xl md:text-7xl"
        >
          {t.hero.headline1}
          <br />
          <span className="bg-gradient-to-r from-white via-white to-mist-400 bg-clip-text font-normal text-transparent">
            {t.hero.headline2}
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="mt-6 max-w-xl text-balance text-base leading-relaxed text-mist-400 sm:text-lg"
        >
          {t.hero.sub}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.62 }}
          className="mt-10 flex flex-wrap items-center justify-center gap-4"
        >
          <a
            href="#projects"
            onClick={(e) => {
              e.preventDefault();
              document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" });
            }}
            className="group flex items-center gap-2 rounded-full bg-signal-500 px-6 py-3 text-sm font-medium text-white transition-all hover:scale-[1.03] hover:bg-signal-600"
          >
            {t.hero.ctaPrimary}
            <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
          <a
            href="/Mohamed-El-Haddady-CV.pdf"
            download
            className="glass group flex items-center gap-2 rounded-full px-6 py-3 text-sm font-medium text-mist-100 transition-all hover:scale-[1.03] hover:border-white/20"
          >
            {t.hero.ctaSecondary}
            <Download className="h-4 w-4 transition-transform group-hover:translate-y-0.5" />
          </a>
        </motion.div>

        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 1 }}
          onClick={() =>
            document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })
          }
          className="mt-16 flex flex-col items-center gap-2 text-mist-600 transition-colors hover:text-mist-300"
        >
          <span className="font-mono text-[10px] uppercase tracking-[0.2em]">
            {t.hero.scroll}
          </span>
          <motion.span
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.8, repeat: Infinity, ease: "easeInOut" }}
          >
            <ArrowDown className="h-4 w-4" />
          </motion.span>
        </motion.button>
      </div>
    </section>
  );
}
