"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import { experience } from "@/lib/data";
import RevealOnScroll from "@/components/ui/RevealOnScroll";

export default function Experience() {
  const { t, lang } = useLanguage();

  return (
    <section id="experience" className="relative border-t border-white/5 py-28 sm:py-36">
      <div className="mx-auto max-w-6xl px-6">
        <RevealOnScroll>
          <span className="eyebrow flex items-center gap-2 text-signal-glow">
            <span className="h-px w-8 bg-signal-500" />
            {t.experience.eyebrow}
          </span>
        </RevealOnScroll>

        <RevealOnScroll delay={0.05}>
          <h2 className="mt-6 max-w-lg text-balance text-3xl font-light leading-tight tracking-tight text-mist-50 sm:text-4xl">
            {t.experience.title}
          </h2>
        </RevealOnScroll>

        <div className="mt-16 flex flex-col">
          {experience.map((job, i) => (
            <RevealOnScroll key={job.id} delay={0.08 * i}>
              <div className="group grid gap-4 border-t border-white/5 py-10 first:border-t-0 md:grid-cols-[160px_1fr]">
                <div className="font-mono text-xs uppercase tracking-widest text-mist-500">
                  {job.period[lang]}
                </div>
                <div>
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <h3 className="text-xl font-normal text-mist-50 transition-colors group-hover:text-signal-glow">
                      {job.role[lang]}
                    </h3>
                    <span className="font-mono text-xs text-mist-500">{job.company}</span>
                  </div>
                  <p className="mt-3 max-w-2xl text-sm leading-relaxed text-mist-400">
                    {job.description[lang]}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {job.tech.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full border border-white/8 px-2.5 py-1 font-mono text-[10px] uppercase tracking-wide text-mist-500"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </RevealOnScroll>
          ))}
        </div>
      </div>
    </section>
  );
}
