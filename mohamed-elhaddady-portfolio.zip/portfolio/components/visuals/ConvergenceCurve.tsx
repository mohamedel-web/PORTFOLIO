"use client";

import { motion } from "framer-motion";

/**
 * Ambient hero visual: a stylised cycloid/ODE trajectory with three
 * numerical approximations (Euler, RK2, RK4) converging on the true
 * curve — a direct nod to the graduation project. Doubles as the
 * page's signature element instead of generic particles.
 */
export default function ConvergenceCurve() {
  const truePath =
    "M -40 260 C 60 60, 180 40, 260 160 C 340 280, 460 300, 560 140 C 640 20, 720 40, 800 180";

  const euler =
    "M -40 270 L 20 230 L 80 210 L 140 150 L 200 170 L 260 200 L 320 260 L 380 300 L 440 260 L 500 200 L 560 170 L 620 100 L 680 90 L 740 150 L 800 190";

  const rk2 =
    "M -40 264 C 40 180, 120 90, 220 150 C 300 195, 380 300, 460 270 C 540 245, 600 100, 680 70 C 730 55, 770 120, 800 185";

  const rk4 =
    "M -40 261 C 55 65, 175 42, 258 158 C 336 276, 458 298, 558 142 C 636 24, 718 42, 800 179";

  return (
    <svg
      viewBox="0 0 800 340"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="h-full w-full"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="trueGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#3B82F6" stopOpacity="0" />
          <stop offset="15%" stopColor="#60A5FA" stopOpacity="0.9" />
          <stop offset="85%" stopColor="#60A5FA" stopOpacity="0.9" />
          <stop offset="100%" stopColor="#3B82F6" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* faint step approximation — Euler */}
      <motion.path
        d={euler}
        stroke="#3B82F6"
        strokeOpacity={0.18}
        strokeWidth={1}
        strokeDasharray="2 4"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 2.2, ease: "easeInOut", delay: 0.2 }}
      />

      {/* RK2 approximation */}
      <motion.path
        d={rk2}
        stroke="#3B82F6"
        strokeOpacity={0.28}
        strokeWidth={1.1}
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 2.2, ease: "easeInOut", delay: 0.5 }}
      />

      {/* RK4 approximation — near-exact */}
      <motion.path
        d={rk4}
        stroke="#93C5FD"
        strokeOpacity={0.35}
        strokeWidth={1.2}
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 2.2, ease: "easeInOut", delay: 0.8 }}
      />

      {/* the true analytic curve */}
      <motion.path
        d={truePath}
        stroke="url(#trueGrad)"
        strokeWidth={1.6}
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 2.4, ease: "easeInOut", delay: 1.1 }}
      />

      {/* traveling point along the true curve, ambient loop */}
      <motion.circle
        r={3.5}
        fill="#60A5FA"
        initial={{ offsetDistance: "0%", opacity: 0 }}
        animate={{ offsetDistance: "100%", opacity: [0, 1, 1, 0] }}
        transition={{
          duration: 6,
          delay: 2,
          repeat: Infinity,
          ease: "linear",
        }}
        style={{ offsetPath: `path("${truePath}")` } as React.CSSProperties}
      />
    </svg>
  );
}
