"use client";

import { useLanguage } from "@/lib/i18n/LanguageContext";
import { contactInfo } from "@/lib/data";

export default function Footer() {
  const { t } = useLanguage();
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/5 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 text-center sm:flex-row sm:text-left">
        <p className="font-mono text-[11px] text-mist-600">
          © {year} Mohamed El-Haddady. {t.footer.built}
        </p>
        <div className="flex items-center gap-5 font-mono text-[11px] uppercase tracking-widest text-mist-500">
          <a href={`mailto:${contactInfo.email}`} className="underline-grow hover:text-mist-100">
            Email
          </a>
          <a href={contactInfo.linkedin} target="_blank" rel="noreferrer" className="underline-grow hover:text-mist-100">
            LinkedIn
          </a>
          <a href={contactInfo.github} target="_blank" rel="noreferrer" className="underline-grow hover:text-mist-100">
            GitHub
          </a>
        </div>
      </div>
    </footer>
  );
}
