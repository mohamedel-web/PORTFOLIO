export const skillGroups = [
  {
    key: "languages",
    items: ["Python", "Java", "C", "C++", "JavaScript", "PHP", "SQL", "PL/SQL"],
  },
  {
    key: "web",
    items: ["HTML5", "CSS3", "Bootstrap", "TailwindCSS", "Laravel", "WordPress"],
  },
  {
    key: "data",
    items: ["MySQL", "Jupyter Notebooks", "IBM SPSS", "PARI/GP"],
  },
  {
    key: "math",
    items: [
      "Numerical Methods (Euler, RK2, RK4)",
      "Differential Equations",
      "Statistics",
      "Machine Learning",
    ],
  },
  {
    key: "tools",
    items: ["Git", "GitHub", "Linux / Kali", "Arduino", "Networking"],
  },
] as const;

export const experience = [
  {
    id: "ghafsai",
    company: "Commune de Ghafsai",
    period: { en: "Apr 2023 — Jun 2023", fr: "Avril 2023 — Juin 2023" },
    role: {
      en: "Software Engineering Intern",
      fr: "Stagiaire en Développement Logiciel",
    },
    description: {
      en: "Designed and built Mowatin, a citizen-service web application that lets residents submit, track and manage administrative document requests online — replacing a fully manual, in-person process.",
      fr: "Conception et développement de Mowatin, une application web de services citoyens permettant aux habitants de soumettre, suivre et gérer leurs demandes de documents administratifs en ligne — en remplacement d'un processus entièrement manuel.",
    },
    tech: ["PHP", "HTML", "CSS", "JavaScript", "Bootstrap", "MySQL"],
  },
  {
    id: "atlanta",
    company: "Atlanta Sanad Assurance",
    period: { en: "Jun 2022 — Jul 2022", fr: "Juin 2022 — Juillet 2022" },
    role: { en: "Web Development Intern", fr: "Stagiaire en Développement Web" },
    description: {
      en: "Built and launched a WordPress blog for the agency's management team, improving the company's online communication and public presence.",
      fr: "Création et mise en ligne d'un blog WordPress pour la direction de l'agence, contribuant à améliorer la communication et la présence en ligne de l'entreprise.",
    },
    tech: ["WordPress", "CMS", "Content Strategy"],
  },
] as const;

export const projects = [
  {
    id: "cycloid-ode",
    title: { en: "Cycloid Motion Simulator (ODE)", fr: "Simulateur de Cycloïde (EDO)" },
    tag: { en: "Graduation Project", fr: "Projet de fin d'études" },
    description: {
      en: "A Python simulator modeling motion along a cycloid as an ordinary differential equation. Implements and compares five numerical schemes — Euler, Implicit Euler, Modified Euler, RK2 and RK4 — with full error and convergence analysis.",
      fr: "Simulateur Python modélisant le mouvement sur une cycloïde via une équation différentielle ordinaire. Implémente et compare cinq schémas numériques — Euler, Euler implicite, Euler modifiée, RK2 et RK4 — avec analyse complète des erreurs et de la convergence.",
    },
    tech: ["Python", "NumPy", "Matplotlib", "Numerical Analysis"],
    github: "#",
    demo: null,
    featured: true,
  },
  {
    id: "mowatin",
    title: { en: "Mowatin — Citizen Services Platform", fr: "Mowatin — Plateforme de Services Citoyens" },
    tag: { en: "Internship Project", fr: "Projet de stage" },
    description: {
      en: "A full-stack web application for the Commune of Ghafsai that digitizes administrative document requests — from submission to tracking to fulfillment — for residents and staff.",
      fr: "Application web full-stack pour la Commune de Ghafsai qui numérise les demandes de documents administratifs — de la soumission au suivi jusqu'au traitement — pour les habitants et le personnel.",
    },
    tech: ["PHP", "HTML", "CSS", "JavaScript", "Bootstrap", "MySQL"],
    github: "#",
    demo: null,
    featured: true,
  },
  {
    id: "rfid-attendance",
    title: { en: "RFID Attendance System", fr: "Système de Présence RFID" },
    tag: { en: "Academic Project", fr: "Projet académique" },
    description: {
      en: "An automated attendance-tracking system built with an Arduino RFID reader and a lightweight web dashboard, developed in a two-person team.",
      fr: "Système de gestion de présence automatisé construit autour d'un lecteur RFID Arduino et d'un tableau de bord web léger, développé en binôme.",
    },
    tech: ["Arduino", "C", "HTML", "CSS", "PHP", "JavaScript"],
    github: "#",
    demo: null,
    featured: false,
  },
] as const;

export const education = [
  {
    id: "master-maim",
    degree: {
      en: "Master of Excellence — Applied Mathematics & Machine Intelligence",
      fr: "Master d'Excellence — Mathématiques Appliquées à l'Intelligence des Machines",
    },
    school: "Faculté Polydisciplinaire de Nador",
    period: "2025 — Present",
    current: true,
  },
  {
    id: "licence-maim",
    degree: {
      en: "Bachelor of Excellence — Applied Mathematics & Machine Intelligence",
      fr: "Licence d'Excellence — Mathématiques Appliquées à l'Intelligence des Machines",
    },
    school: "Faculté Polydisciplinaire de Nador",
    period: "2024 — 2025",
    current: false,
  },
  {
    id: "dut",
    degree: {
      en: "University Diploma of Technology — Computer Science",
      fr: "Diplôme Universitaire de Technologie — Informatique",
    },
    school: "École Supérieure de Technologie de Guelmim",
    period: "2021 — 2023",
    current: false,
  },
  {
    id: "bac",
    degree: {
      en: "Baccalaureate — Physical Sciences",
      fr: "Baccalauréat — Sciences Physiques",
    },
    school: "Lycée Imam Choutaibi, Ghafsai",
    period: "2020 — 2021",
    current: false,
  },
] as const;

export const contactInfo = {
  email: "mohamedhaddady8@gmail.com",
  phone: "+212 609 096 912",
  linkedin: "https://www.linkedin.com/in/mohamed-el-haddady-172457238",
  github: "https://github.com/",
  location: "Ghafsai, Taounate, Morocco",
};
