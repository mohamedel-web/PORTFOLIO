export type Lang = "en" | "fr";

interface StatItem {
  value: string;
  label: string;
}

interface TranslationShape {
  nav: {
    about: string;
    skills: string;
    experience: string;
    projects: string;
    education: string;
    github: string;
    contact: string;
    cta: string;
  };
  hero: {
    eyebrow: string;
    role: string;
    headline1: string;
    headline2: string;
    sub: string;
    ctaPrimary: string;
    ctaSecondary: string;
    scroll: string;
    status: string;
  };
  about: {
    eyebrow: string;
    title: string;
    p1: string;
    p2: string;
    p3: string;
    quote: string;
    stats: StatItem[];
  };
  skills: {
    eyebrow: string;
    title: string;
    sub: string;
    categories: {
      languages: string;
      web: string;
      data: string;
      math: string;
      tools: string;
    };
  };
  experience: {
    eyebrow: string;
    title: string;
    present: string;
  };
  projects: {
    eyebrow: string;
    title: string;
    sub: string;
    github: string;
    demo: string;
    soon: string;
    tech: string;
    more: string;
  };
  education: {
    eyebrow: string;
    title: string;
  };
  github: {
    eyebrow: string;
    title: string;
    sub: string;
    viewProfile: string;
    stats: StatItem[];
  };
  contact: {
    eyebrow: string;
    title: string;
    sub: string;
    email: string;
    phone: string;
    linkedin: string;
    github: string;
    cv: string;
    formName: string;
    formEmail: string;
    formMessage: string;
    formSend: string;
    formPlaceholderName: string;
    formPlaceholderEmail: string;
    formPlaceholderMessage: string;
  };
  footer: {
    built: string;
    backToTop: string;
  };
}

export const translations: Record<Lang, TranslationShape> = {
  en: {
    nav: {
      about: "About",
      skills: "Skills",
      experience: "Experience",
      projects: "Projects",
      education: "Education",
      github: "GitHub",
      contact: "Contact",
      cta: "Let's talk",
    },
    hero: {
      eyebrow: "Portfolio — Rabat / Nador, Morocco",
      role: "Applied Mathematics & Machine Intelligence",
      headline1: "Turning equations",
      headline2: "into intelligent systems.",
      sub: "Master's student in Applied Mathematics & Machine Intelligence (MAIM), building at the intersection of numerical methods, software engineering and artificial intelligence.",
      ctaPrimary: "View projects",
      ctaSecondary: "Download CV",
      scroll: "Scroll",
      status: "Open to internships",
    },
    about: {
      eyebrow: "About",
      title: "A mathematician who ships code.",
      p1: "I'm Mohamed — a Computer & Network Engineering graduate now pursuing a Master's of Excellence in Applied Mathematics & Machine Intelligence at the Faculté Polydisciplinaire de Nador.",
      p2: "My work sits between two disciplines: the rigor of numerical mathematics and the craft of software engineering. I care about understanding systems from first principles — whether that's a differential equation, a neural network, or a production web app — before I trust them.",
      p3: "Outside coursework, I build small, complete things: citizen-service platforms, RFID attendance systems, numerical simulators. I'm currently looking for an internship where I can apply mathematical thinking to real AI and ML problems.",
      quote: "I don't just want models that work — I want to understand why they work.",
      stats: [
        { value: "3+", label: "Years building software" },
        { value: "5", label: "Numerical methods implemented" },
        { value: "3", label: "Languages spoken" },
        { value: "2", label: "Professional internships" },
      ],
    },
    skills: {
      eyebrow: "Capabilities",
      title: "A stack built for AI and applied mathematics.",
      sub: "Core languages, mathematical foundations, and the tools I use to move from idea to implementation.",
      categories: {
        languages: "Languages",
        web: "Web & Frameworks",
        data: "Data & Databases",
        math: "Mathematics & AI",
        tools: "Systems & Tools",
      },
    },
    experience: {
      eyebrow: "Experience",
      title: "Where I've applied it so far.",
      present: "Present",
    },
    projects: {
      eyebrow: "Selected work",
      title: "Projects worth a closer look.",
      sub: "A mix of applied mathematics, embedded systems, and full-stack engineering — with more on the way.",
      github: "Code",
      demo: "Live demo",
      soon: "Coming soon",
      tech: "Technologies",
      more: "More projects are on the way — this space grows as I ship.",
    },
    education: {
      eyebrow: "Education",
      title: "Academic path.",
    },
    github: {
      eyebrow: "GitHub",
      title: "Building in public.",
      sub: "A snapshot of ongoing activity — repositories, commits, and the projects taking shape right now.",
      viewProfile: "View GitHub profile",
      stats: [
        { label: "Public repositories", value: "12+" },
        { label: "Languages used", value: "8" },
        { label: "Core stack", value: "Python" },
        { label: "Focus area", value: "AI / ML" },
      ],
    },
    contact: {
      eyebrow: "Contact",
      title: "Let's build something intelligent.",
      sub: "Open to internships, junior AI/ML roles, and collaborative projects. I usually reply within a day.",
      email: "Email",
      phone: "Phone",
      linkedin: "LinkedIn",
      github: "GitHub",
      cv: "Download CV",
      formName: "Name",
      formEmail: "Email",
      formMessage: "Message",
      formSend: "Send message",
      formPlaceholderName: "Your name",
      formPlaceholderEmail: "you@example.com",
      formPlaceholderMessage: "Tell me about the opportunity...",
    },
    footer: {
      built: "Designed & built by Mohamed El-Haddady.",
      backToTop: "Back to top",
    },
  },
  fr: {
    nav: {
      about: "À propos",
      skills: "Compétences",
      experience: "Expérience",
      projects: "Projets",
      education: "Formation",
      github: "GitHub",
      contact: "Contact",
      cta: "Me contacter",
    },
    hero: {
      eyebrow: "Portfolio — Nador, Maroc",
      role: "Mathématiques Appliquées & Intelligence Machine",
      headline1: "Transformer des équations",
      headline2: "en systèmes intelligents.",
      sub: "Étudiant en Master d'Excellence en Mathématiques Appliquées à l'Intelligence des Machines (MAIM), à la croisée des méthodes numériques, du génie logiciel et de l'intelligence artificielle.",
      ctaPrimary: "Voir les projets",
      ctaSecondary: "Télécharger le CV",
      scroll: "Défiler",
      status: "Ouvert aux stages",
    },
    about: {
      eyebrow: "À propos",
      title: "Un mathématicien qui livre du code.",
      p1: "Je m'appelle Mohamed — diplômé en Ingénierie Informatique et Réseaux, actuellement en Master d'Excellence en Mathématiques Appliquées à l'Intelligence des Machines à la Faculté Polydisciplinaire de Nador.",
      p2: "Mon travail se situe entre deux disciplines : la rigueur des mathématiques numériques et l'art du génie logiciel. Je tiens à comprendre les systèmes à partir de leurs principes fondamentaux — une équation différentielle, un réseau de neurones ou une application web en production — avant de leur faire confiance.",
      p3: "En dehors des cours, je construis des projets concrets et aboutis : plateformes de services citoyens, systèmes de présence RFID, simulateurs numériques. Je recherche actuellement un stage me permettant d'appliquer une pensée mathématique à de véritables problématiques d'IA et de Machine Learning.",
      quote: "Je ne veux pas seulement des modèles qui fonctionnent — je veux comprendre pourquoi ils fonctionnent.",
      stats: [
        { value: "3+", label: "Années de développement" },
        { value: "5", label: "Méthodes numériques implémentées" },
        { value: "3", label: "Langues parlées" },
        { value: "2", label: "Stages professionnels" },
      ],
    },
    skills: {
      eyebrow: "Compétences",
      title: "Une stack pensée pour l'IA et les mathématiques appliquées.",
      sub: "Langages, fondations mathématiques et outils que j'utilise pour passer de l'idée à l'implémentation.",
      categories: {
        languages: "Langages",
        web: "Web & Frameworks",
        data: "Données & Bases de données",
        math: "Mathématiques & IA",
        tools: "Systèmes & Outils",
      },
    },
    experience: {
      eyebrow: "Expérience",
      title: "Là où je l'ai déjà appliqué.",
      present: "Présent",
    },
    projects: {
      eyebrow: "Travaux sélectionnés",
      title: "Des projets qui méritent le détour.",
      sub: "Un mélange de mathématiques appliquées, de systèmes embarqués et de développement full-stack — d'autres arrivent bientôt.",
      github: "Code",
      demo: "Démo live",
      soon: "Bientôt disponible",
      tech: "Technologies",
      more: "D'autres projets arrivent bientôt — cet espace grandit au fil de mes réalisations.",
    },
    education: {
      eyebrow: "Formation",
      title: "Parcours académique.",
    },
    github: {
      eyebrow: "GitHub",
      title: "Construire en public.",
      sub: "Un aperçu de l'activité en cours — dépôts, commits et projets en construction.",
      viewProfile: "Voir le profil GitHub",
      stats: [
        { label: "Dépôts publics", value: "12+" },
        { label: "Langages utilisés", value: "8" },
        { label: "Stack principale", value: "Python" },
        { label: "Domaine de focus", value: "IA / ML" },
      ],
    },
    contact: {
      eyebrow: "Contact",
      title: "Construisons quelque chose d'intelligent.",
      sub: "Ouvert aux stages, postes juniors en IA/ML et projets collaboratifs. Je réponds généralement sous 24h.",
      email: "Email",
      phone: "Téléphone",
      linkedin: "LinkedIn",
      github: "GitHub",
      cv: "Télécharger le CV",
      formName: "Nom",
      formEmail: "Email",
      formMessage: "Message",
      formSend: "Envoyer le message",
      formPlaceholderName: "Votre nom",
      formPlaceholderEmail: "vous@exemple.com",
      formPlaceholderMessage: "Parlez-moi de l'opportunité...",
    },
    footer: {
      built: "Conçu et développé par Mohamed El-Haddady.",
      backToTop: "Haut de page",
    },
  },
};

export type Translations = TranslationShape;
