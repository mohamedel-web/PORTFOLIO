Place your files here:
- profile.jpg   -> your photo (used in the Hero section)
- Mohamed-El-Haddady-CV.pdf -> your CV (used by the "Download CV" buttons)

Nothing else to configure — the site already points to these filenames.
