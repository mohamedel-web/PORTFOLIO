import type { Metadata } from "next";
import { Inter, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { LanguageProvider } from "@/lib/i18n/LanguageContext";
import CursorGlow from "@/components/CursorGlow";
import ScrollProgress from "@/components/ScrollProgress";
import BackToTop from "@/components/BackToTop";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const mono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Mohamed El-Haddady — AI & Machine Intelligence Engineer",
  description:
    "Portfolio of Mohamed El-Haddady — Applied Mathematics & Machine Intelligence graduate student, building intelligent systems at the intersection of mathematics, software engineering and AI.",
  keywords: [
    "Mohamed El-Haddady",
    "AI Engineer",
    "Machine Learning",
    "Applied Mathematics",
    "MAIM",
    "Portfolio",
  ],
  authors: [{ name: "Mohamed El-Haddady" }],
  openGraph: {
    title: "Mohamed El-Haddady — AI & Machine Intelligence Engineer",
    description:
      "Applied Mathematics & Machine Intelligence graduate student. AI, ML, Data Science, Cybersecurity.",
    type: "website",
    locale: "en_US",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${inter.variable} ${mono.variable}`}>
      <body className="bg-ink-950 text-mist-50 selection:bg-signal-500/30">
        <LanguageProvider>
          <div className="noise" aria-hidden="true" />
          <ScrollProgress />
          <CursorGlow />
          {children}
          <BackToTop />
        </LanguageProvider>
      </body>
    </html>
  );
}
